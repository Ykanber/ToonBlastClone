using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHasColor 
{ // for boxes and maybe in future balloons
    PieceColor GetColor(); 
}
