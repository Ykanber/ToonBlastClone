using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxGoalPrefab : MonoBehaviour
{
    public PieceColor color; // goal has color and game piece type

    public GamePieceType type;
}
